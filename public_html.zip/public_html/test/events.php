<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events & News Hub</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to CSS -->
    <!-- Add libraries for Bootstrap or jQuery if needed -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header Section -->
    <header>
        <h1>Events & News Hub</h1>
        <p>Stay updated with the latest happenings, achievements, and upcoming events around the globe.</p>
        <nav>
            <a href="#calendar">Calendar</a>
            <a href="#news">News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <div class="calendar-container">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search Events">
                <button type="submit">Search</button>
            </form>

            <div class="event-list">
                <?php
                // Dummy events (replace with database logic)
                $events = [
                    ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online'],
                    ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York'],
                ];

                foreach ($events as $event) {
                    echo "<div class='event'>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#'>Register Now</a>
                          </div>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            // Dummy news data (replace with database logic)
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <h3>{$item['title']}</h3>
                        <p>{$item['summary']}</p>
                        <a href='{$item['link']}'>Read More</a>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Photo and Video Galleries Section -->
    <section id="gallery">
        <h2>Gallery</h2>
        <div class="photo-gallery">
            <h3>Photos</h3>
            <?php
            // Dummy photo links (replace with actual photo paths)
            $photos = ['photo1.jpg', 'photo2.jpg', 'photo3.jpg'];

            foreach ($photos as $photo) {
                echo "<img src='images/$photo' alt='Event Photo' class='gallery-photo'>";
            }
            ?>
        </div>
        <div class="video-gallery">
            <h3>Videos</h3>
            <?php
            // Dummy video links (replace with actual video URLs)
            $videos = ['https://www.youtube.com/embed/video1', 'https://www.youtube.com/embed/video2'];

            foreach ($videos as $video) {
                echo "<iframe src='$video' frameborder='0' allowfullscreen class='gallery-video'></iframe>";
            }
            ?>
        </div>
    </section>

    <!-- Social Media Feed Section -->
    <section id="social">
        <h2>Social Media</h2>
        <div class="social-feed">
            <p>Follow us on:</p>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i> Twitter</a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i> LinkedIn</a>
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i> Facebook</a>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>
</body>
</html>
