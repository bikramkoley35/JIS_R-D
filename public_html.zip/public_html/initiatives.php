
<?php
$servername = "localhost";
$username = "root"; // Change if needed
$password = "";
$dbname = "success_stories_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch stories from database
$sql = "SELECT * FROM stories";
$result = $conn->query($sql);
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Sections Layout</title>

    <script src="https://cdn.tailwindcss.com"></script> <!-- Include Tailwind CSS -->

    <script src="https://cdn.tailwindcss.com"></script>

<!-- Swiper.js CSS & JS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <style>
 body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .main-container {
            background-color: #1a1a5e;
            display: flex;
            justify-content: center;
            padding: 40px 0;
        }

        .content-wrapper {
            width: 80%;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            padding: 10px;
        }

        .left-section {
            grid-row: 1 / 3;
            border-radius: 10px;
            box-shadow: 7px 7px black;
            padding: 20px;
            text-align: left;
            background-color: rgb(173, 197, 245);
            overflow-y: auto;
            max-height: 600px;
        }

        .left-section img {
            width: 100%;
            height: 240px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .left-section ul {
            padding-left: 20px;
        }

        .left-section li {
            margin-bottom: 15px;
            font-size: 16px;
            color: #333;
        }

        .left-section a {
            color: #0044cc;
            text-decoration: none;
            font-size: 14px;
        }

        .right-top {
            padding: 20px;
            background-color: rgb(197, 196, 198);
        }

        .right-top ul {
            padding-left: 20px;
        }

        .right-top li {
            margin-bottom: 10px;
            font-size: 16px;
            color: #555;
        }

        .right-bottom {
            padding: 20px;
            background-color: rgb(127, 127, 129);
        }

        .list-item {
            display: flex;
            align-items: center;
            background: #f3f4f6;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .list-item span {
            font-size: 20px;
            margin-right: 10px;
        }

        h2 {
            color: #333;
            font-size: 40px;
            text-align: center;
        }

        .faq_content{

            margin-left:20px;
            margin-right:20px;
        }

        .faq {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin: 10px 0;
            padding: 15px;
            transition: background 0.3s, color 0.3s, transform 0.2s;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .faq:hover {
            background: rgb(13 148 136 / var(--tw-bg-opacity, 1));
            color: #fff;
            transform: scale(1.02);
        }

        .faq h3 {
            margin: 0;
            padding-left: 30px;
            position: relative;
            font-size: 18px;
            transition: color 0.3s;
            display: flex;
            align-items: center;
        }

        .faq:hover h3 {
            color: #fff;
        }

        .faq h3::before {
            content: '\25CF';
            color: rgb(13 148 136 / var(--tw-bg-opacity, 1));
            font-size: 1.5em;
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            transition: color 0.3s;
        }

        .faq:hover h3::before {
            color: #fff;
        }

        .faq p {
            margin: 10px 0 0;
            display: block;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease-in-out, visibility 0s 0.3s;
        }

        .faq:hover p {
            opacity: 1;
            visibility: visible;
            transition: opacity 0.3s ease-in-out, visibility 0s;
        }

        @media (max-width: 768px) {
            .content-wrapper {
                grid-template-columns: 1fr;
                gap: 10px;
            }

            .left-section {
                max-height: none;
            }

            .right-top,
            .right-bottom {
                padding: 15px;
            }

            .list-item span {
                font-size: 18px;
            }

            h2 {
                font-size: 30px;
            }

            .faq h3 {
                font-size: 16px;
            }
        }

        @media (max-width: 480px) {
            .content-wrapper {
                width: 95%;
                padding: 5px;
            }

            .left-section img {
                height: 180px;
            }

            h2 {
                font-size: 24px;
            }
        }




        h2 {
            background: #0f035c;
            color: white;
            padding: 15px;
            border-radius: 5px;
        }
        
        /* Partners Section */
        .partners-collaborations {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
            padding: 30px;
            margin: 20px;
        }

        .partners, .collaborations {
            flex: 1;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .partners-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }

        .partner-card {
            background: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            width: 180px;
            text-align: center;
        }

        .partner-card img {
            width: 100%;
            height: auto;
        }

        .partner-card:hover {
            transform: scale(1.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #007BFF;
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .partners-collaborations {
                flex-direction: column;
                align-items: center;
            }
        }






        .container {
            text-align: center;
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }
        
        .swiper {
            width: 100%;
            padding: 20px 0;
        }
        
        .swiper-slide {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            text-align: center;
        }
        
        .swiper-slide:hover {
            transform: scale(1.05);
        }
        
        .leader-image {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 15px;
        }
        
        .details .name {
            font-weight: bold;
            font-size: 1.2em;
        }
        
        .company {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .company img {
            width: 80px;
            height: auto;
        }
        
        .read-more {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: #007bff;
            color: #fff;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .read-more:hover {
            background: #0056b3;
        }
        
    </style>
</head>
<body>
    <div class="main-container">
        <div class="content-wrapper">
            <!-- Left Section -->
            <div class="left-section">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCyunAz9xfLThiAEGDKMAQph7wr0eovN26YJ9_Y8P56ZRRCh15tig1IPr3aPsi-T3Y92M&usqp=CAU" alt="Decorative Image">
                <h2>Our Partner Universities</h2>
                <ul>
                    <li>
                        <strong>JIS University:</strong> Renowned for its multidisciplinary approach, JIS University offers programs in engineering, management, science, and law. 
                        <a href="https://jisuniversity.ac.in" target="_blank">Read More</a>
                    </li>
                    <li>
                        <strong>Narula Institute of Technology:</strong> A leading technical institution dedicated to practical learning and skill development. 
                        <a href="https://nit.ac.in" target="_blank">Read More</a>
                    </li>
                    <li>
                        <strong>GNIT (Guru Nanak Institute of Technology):</strong> Known for its hands-on technical education and industry-aligned curriculum. 
                        <a href="https://gnit.ac.in" target="_blank">Read More</a>
                    </li>

                    <li>
                        <strong>JIS University:</strong> Renowned for its multidisciplinary approach, JIS University offers programs in engineering, management, science, and law. 
                        <a href="https://jisuniversity.ac.in" target="_blank">Read More</a>
                    </li>
                    <li>
                        <strong>Narula Institute of Technology:</strong> A leading technical institution dedicated to practical learning and skill development. 
                        <a href="https://nit.ac.in" target="_blank">Read More</a>
                    </li>
                    <li>
                        <strong>GNIT (Guru Nanak Institute of Technology):</strong> Known for its hands-on technical education and industry-aligned curriculum. 
                        <a href="https://gnit.ac.in" target="_blank">Read More</a>
                    </li>

                    <li>
                        <strong>JIS University:</strong> Renowned for its multidisciplinary approach, JIS University offers programs in engineering, management, science, and law. 
                        <a href="https://jisuniversity.ac.in" target="_blank">Read More</a>
                    </li>
                    <li>
                        <strong>Narula Institute of Technology:</strong> A leading technical institution dedicated to practical learning and skill development. 
                        <a href="https://nit.ac.in" target="_blank">Read More</a>
                    </li>
                    <li>
                        <strong>GNIT (Guru Nanak Institute of Technology):</strong> Known for its hands-on technical education and industry-aligned curriculum. 
                        <a href="https://gnit.ac.in" target="_blank">Read More</a>
                    </li>
                </ul>
            </div>

            <!-- Right Top Section -->
            <div class="right-top">
                <h2>Scholarships Available</h2>
                <ul>
                    <li><strong>Merit-Based Scholarship:</strong> Awarded to students with outstanding academic achievements.</li>
                    <li><strong>Need-Based Scholarship:</strong> Financial aid for students from low-income families.</li>
                    <li><strong>Sports Scholarship:</strong> Rewards for exceptional performance in sports activities.</li>
                    <li><strong>Research Grants:</strong> Funding for students involved in innovative research projects.</li>
                </ul>
            </div>

            <!-- Right Bottom Section -->
            <div class="right-bottom">
                <div class="list-item"><span>➡️</span> "Fill out the online application form with accurate details."</div>
                <div class="list-item"><span>➡️</span> "Upload the required documents, including transcripts and certificates."</div>
                <div class="list-item"><span>➡️</span> "Submit the application fee as per the guidelines."</div>
                <div class="list-item"><span>➡️</span> "Await confirmation and attend the interview or counseling session, if required."</div>
            </div>
        </div>
    </div>


<div class="faq_content">   
    
  <h2>Frequently Asked Questions (FAQs)</h2>
    <div class="faq">
        <h3>What are global partnerships?</h3>
        <p>Global partnerships are collaborative agreements between our college and international institutions aimed at enhancing educational opportunities, research, and cultural exchange.</p>
    </div>
    <div class="faq">
        <h3>How do global partnerships benefit students?</h3>
        <p>Students benefit from global partnerships through access to exchange programs, joint research initiatives, and opportunities to study abroad, which enrich their academic experience and cultural understanding.</p>
    </div>
    <div class="faq">
        <h3>How can I get involved in global partnerships?</h3>
        <p>Students can get involved by participating in exchange programs, attending informational sessions, and reaching out to the Office of Global Partnerships for more information.</p>
    </div>
    <div class="faq">
        <h3>Who can I contact for more information?</h3>
        <p>For more information about global partnerships, please contact the Office of Global Partnerships at <a href="mailto:globalpartnerships@college.edu" style="color: #fff; text-decoration: underline;">globalpartnerships@college.edu</a>.</p>
    </div>

 </div>  



 <div class="partners-collaborations">
    <!-- Partners Section -->
    <section class="partners">
        <h2>Our Partners</h2>
        <div class="partners-container">
            <div class="partner-card"><img src="partner1.png" alt="Partner 1"></div>
            <div class="partner-card"><img src="partner2.png" alt="Partner 2"></div>
            <div class="partner-card"><img src="partner3.png" alt="Partner 3"></div>
            <div class="partner-card"><img src="partner4.png" alt="Partner 4"></div>
            <div class="partner-card"><img src="partner1.png" alt="Partner 1"></div>
            <div class="partner-card"><img src="partner2.png" alt="Partner 2"></div>
            <div class="partner-card"><img src="partner3.png" alt="Partner 3"></div>
            <div class="partner-card"><img src="partner4.png" alt="Partner 4"></div>
        </div>
    </section>

    <!-- Collaboration Table -->
    <section class="collaborations">
        <h2>University Collaborations</h2>
        <table>
            <tr><th>Sl No</th><th>University</th><th>Purpose</th></tr>
            <tr><td>1</td><td>Harvard</td><td>Research Collaboration</td></tr>
            <tr><td>2</td><td>Stanford</td><td>Student Exchange</td></tr>
        </table>
    </section>



</div>



<section class="container mx-auto p-6">
    <h2 class="text-3xl font-bold text-center mb-6">🏆 Success Stories</h2>

    <div class="swiper mySwiper overflow-hidden">
        <div class="swiper-wrapper">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '
                        <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                            <img src="' . $row["image_url"] . '" class="w-full h-40 object-cover rounded-md" alt="Story">
                            <h3 class="text-lg font-semibold mt-3">' . $row["title"] . '</h3>
                            <p class="text-sm text-gray-600">' . $row["description"] . '</p>
                            <p class="text-sm font-medium text-gray-800">🏢 Company: ' . $row["company_name"] . '</p>
                            <p class="text-sm font-medium text-green-600">💰 Offered Package: ' . $row["offered_lpa"] . ' LPA</p>
                        </div>';
                }
            } else {
                echo "<p class='text-center text-gray-500'>No stories available.</p>";
            }
            ?>
        </div>

        <div class="swiper-pagination"></div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>
</section>



<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
    var swiper = new Swiper(".mySwiper", {
        loop: true,  // Enables infinite scrolling
        autoplay: {
            delay: 2500,  // Auto slide every 2.5s
            disableOnInteraction: false,
        },
        slidesPerView: 1,   // Show 1 slide on small screens
        spaceBetween: 30,   // Adds spacing between slides
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        breakpoints: {  // Responsive settings
            768: { slidesPerView: 2 },  // 2 slides on tablets
            1024: { slidesPerView: 3 }, // 3 slides on desktops
        },
    });
</script>



</body>
</html>
