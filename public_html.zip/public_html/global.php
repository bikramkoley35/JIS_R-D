<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global Partnerships</title>
    <script src="https://cdn.tailwindcss.com"></script> <!-- Include Tailwind CSS -->

    <script src="https://cdn.tailwindcss.com"></script>

<!-- Swiper.js CSS & JS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
</head>
<?php include 'assets/phppages/headernav.php'; ?>
<body class="bg-gray-100">

<section class="container mx-auto p-6">
    <!-- Section Title -->
    <h2 class="text-3xl font-bold text-center mb-6">🌍 Our Global Partnerships</h2>

    <!-- Interactive Map (Properly Embedded & Responsive) -->
    <div class="relative w-full h-96 sm:h-[480px] bg-gray-200 rounded-lg shadow-md overflow-hidden">
        <iframe 
            src="https://www.google.com/maps/d/u/0/embed?mid=1eW79709XemcNMG7kEoMgypLjyQxQN30&ehbc=2E312F" 
            class="w-full h-full border-0">
        </iframe>
    </div>



    <section class="container mx-auto p-6">
    <!-- Section Title -->
    <h2 class="text-3xl font-bold text-center mb-6">🏆 Success Stories</h2>

    <!-- Swiper Carousel -->
    <div class="swiper mySwiper overflow-hidden">
        <div class="swiper-wrapper">
            <!-- Card 1 -->
            <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img src="https://www.naukri.com/cloudgateway-fastforward/ff-content-services/v0/unauth/cms/photo?id=8bd9b3512802afcf242d9060cf00c18824d2d992680979627673ececcebf7fcc8ea78075042b1dc841810d381bd0b70b1923bccb48f97686716bbacdf68c13eab39256bcdd88f9b25c4f31944917d4da&postTypeId=c4eff10da33c562d3e88af8f60fcf6cecdf3e35370f49177&source=ff" class="w-full h-40 object-cover rounded-md" alt="Story 1">
                <h3 class="text-lg font-semibold mt-3">Collaboration with XYZ University</h3>
                <p class="text-sm text-gray-600">Impactful research in AI and sustainability.</p>
            </div>

            <!-- Card 2 -->
            <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img src="https://professional.dce.harvard.edu/wp-content/uploads/sites/9/2022/08/why-is-professional-development-important.jpg" class="w-full h-40 object-cover rounded-md" alt="Story 2">
                <h3 class="text-lg font-semibold mt-3">Tech Innovation with ABC Corp</h3>
                <p class="text-sm text-gray-600">Developing next-gen smart devices.</p>
            </div>

            <!-- Card 3 -->
            <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8LfQhWs7XiCtvDL8DoHXUojrk_CQ6JbP8iQ&s" class="w-full h-40 object-cover rounded-md" alt="Story 3">
                <h3 class="text-lg font-semibold mt-3">Green Energy Partnership</h3>
                <p class="text-sm text-gray-600">Advancing sustainable energy solutions.</p>
            </div>


            <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRty50rNo9WiTu5rt_dYyACIw6qgQGxbECHoA&s" class="w-full h-40 object-cover rounded-md" alt="Story 3">
                <h3 class="text-lg font-semibold mt-3">Green Energy Partnership</h3>
                <p class="text-sm text-gray-600">Advancing sustainable energy solutions.</p>
            </div>


            <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0nGjO-Sx7zlTsWJkcvBGX3BqRqqh4PoXLRA&s" class="w-full h-40 object-cover rounded-md" alt="Story 3">
                <h3 class="text-lg font-semibold mt-3">Green Energy Partnership</h3>
                <p class="text-sm text-gray-600">Advancing sustainable energy solutions.</p>
            </div>


            

            <!-- Add More Cards Here -->
        </div>

        <!-- Swiper Pagination & Navigation -->
        <div class="swiper-pagination"></div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>
</section>




<section class="container mx-auto p-6">
    <h2 class="text-3xl font-bold text-center mb-6">🎥 More Glimpses</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div class="bg-white shadow-lg rounded-lg overflow-hidden">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/JLlIQxA-hzU?si=ENkvoFlcTFupv4qV" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
        <div class="bg-white shadow-lg rounded-lg overflow-hidden">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/uGlDFUZyrqk?si=mAuaqHPp27KgTljd" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
        <div class="bg-white shadow-lg rounded-lg overflow-hidden">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/k0584eW0xS0?si=2b4D8WJSxi0gdpi9" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
    </div>
</section>





<!-- Partnership Inquiry Form & Guidelines -->
<section class="container mx-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Partnership Inquiry Form -->
    <div class="bg-white shadow-lg rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-4">📩 Partnership Inquiry Form</h2>
        <form>
            <label class="block mb-2">Name</label>
            <input type="text" class="w-full border p-2 rounded-md mb-4" placeholder="Your Name" required>
            
            <label class="block mb-2">Organization</label>
            <input type="text" class="w-full border p-2 rounded-md mb-4" placeholder="Your Organization" required>
            
            <label class="block mb-2">Email</label>
            <input type="email" class="w-full border p-2 rounded-md mb-4" placeholder="Your Email" required>
            
            <label class="block mb-2">Message</label>
            <textarea class="w-full border p-2 rounded-md mb-4" placeholder="Your Message" required></textarea>
            
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Start a Partnership</button>
        </form>
    </div>

    <!-- Guidelines Section -->
    <div class="bg-white shadow-lg rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-4">📜 Partnership Guidelines</h2>
        <div class="space-y-3">
            <details class="p-3 border rounded-md cursor-pointer">
                <summary class="font-semibold">Step 1: Initial Contact</summary>
                <p class="text-sm mt-2">Submit your inquiry form to get started.</p>
            </details>
            <details class="p-3 border rounded-md cursor-pointer">
                <summary class="font-semibold">Step 2: Review Process</summary>
                <p class="text-sm mt-2">Our team will review your proposal and reach out.</p>
            </details>
            <details class="p-3 border rounded-md cursor-pointer">
                <summary class="font-semibold">Step 3: Agreement & Next Steps</summary>
                <p class="text-sm mt-2">Finalize terms and begin collaboration.</p>
            </details>
        </div>
        <a href="#" class="block mt-4 text-blue-600 hover:underline">📄 Download Guidelines PDF</a>
    </div>
</section>

    <!-- Success Stories -->

</section>







<script>
  var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,  /* Show 1 slide at a time on small screens */
        spaceBetween: 20,  /* Spacing between slides */
        loop: true,  /* Infinite loop */
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {  /* Responsive behavior */
            640: { slidesPerView: 2 },
            1024: { slidesPerView: 3 }
        },
        scrollbar: {
            el: ".swiper-scrollbar",
            hide: false,
        },
    });
</script>

</body>
</html>
