<?php
// events_news_page.php

// Start the session and include necessary libraries if needed
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Events & News Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* General Styles */
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #444;
        }

        /* Header */
        header {
            background-color: #ffffff;
            color: #2C3E50;
            text-align: center;
            padding: 40px 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 32px;
            font-weight: bold;
        }

        header p {
            font-size: 18px;
            margin-top: 10px;
            color: #7f8c8d;
        }

        nav {
            margin-top: 20px;
        }

        nav a {
            color: #2C3E50;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 25px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        nav a:hover {
            background-color: #3498db;
            color: #fff;
        }

        /* Sections */
        section {
            padding: 60px 15%;
            text-align: center;
            background-color: #ffffff;
            margin: 40px 0;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 30px;
            color: #2C3E50;
            margin-bottom: 30px;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            font-weight: 600;
        }

        /* Buttons */
        button, a.button {
            background-color: #3498db;
            color: white;
            padding: 12px 20px;
            border: none;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            display: inline-block;
            margin-top: 20px;
        }

        button:hover, a.button:hover {
            background-color: #2980b9;
        }

        /* Event & News Items */
        .event, .news-item {
            background-color: #fff;
            padding: 25px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            text-align: left;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: transform 0.3s ease;
        }

        .event:hover, .news-item:hover {
            transform: translateY(-5px);
        }

        .event img, .news-item img {
            width: 100px;
            height: 100px;
            border-radius: 8px;
            margin-right: 20px;
        }

        .event h3, .news-item h3 {
            color: #3498db;
            margin-bottom: 10px;
        }

        .event p, .news-item p {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 10px;
        }

        .news-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Gallery Section */
        .gallery-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .gallery-photo, .gallery-video {
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .gallery-photo {
            width: 280px;
            height: 180px;
            object-fit: cover;
        }

        .gallery-video {
            width: 380px;
            height: 240px;
        }

        /* Social Media */
        .social-feed {
            margin-top: 50px;
            text-align: center;
        }

        .social-feed a {
            margin: 15px;
            font-size: 18px;
            text-decoration: none;
            color: #3498db;
            transition: color 0.3s ease;
        }

        .social-feed a:hover {
            color: #2980b9;
        }

        /* Footer */
        footer {
            background-color: #2C3E50;
            color: white;
            text-align: center;
            padding: 30px;
            font-size: 14px;
            margin-top: 50px;
        }

        footer a {
            color: white;
            text-decoration: none;
            margin: 0 12px;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <!-- Header Section -->
    <header>
        <h1>College Events & News Hub</h1>
        <p>Your go-to platform for the latest college updates and exciting events.</p>
        <nav>
            <a href="#calendar">Upcoming Events</a>
            <a href="#news">Latest News</a>
            <a href="#gallery">Gallery</a>
            <a href="#social">Social Media</a>
        </nav>
    </header>

    <!-- Calendar Section -->
    <section id="calendar">
        <h2>Upcoming Events</h2>
        <form method="GET" action="" style="margin-bottom: 30px;">
            <input type="text" name="search" placeholder="Search Events" style="padding: 10px 15px; font-size: 16px; border-radius: 5px; border: 1px solid #ddd;">
            <button type="submit">Search</button>
        </form>

        <div class="event-list">
            <?php
            $events = [
                ['title' => 'Webinar on AI', 'date' => '2025-02-01', 'location' => 'Online', 'image' => 'event1.jpg'],
                ['title' => 'Global Conference on Education', 'date' => '2025-03-15', 'location' => 'New York', 'image' => 'event2.jpg'],
            ];

            foreach ($events as $event) {
                echo "<div class='event'>
                        <img src='{$event['image']}' alt='{$event['title']}'>
                        <div>
                            <h3>{$event['title']}</h3>
                            <p>Date: {$event['date']}</p>
                            <p>Location: {$event['location']}</p>
                            <a href='#' class='button'>Register Now</a>
                        </div>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Latest News Section -->
    <section id="news">
        <h2>Latest News</h2>
        <div class="news-container">
            <?php
            $news = [
                ['title' => 'New Scholarship Program Launched', 'summary' => 'We are excited to announce...', 'link' => '#', 'image' => 'news1.jpg'],
                ['title' => 'Partnership with XYZ', 'summary' => 'A new collaboration with XYZ...', 'link' => '#', 'image' => 'news2.jpg']
            ];

            foreach ($news as $item) {
                echo "<div class='news-item'>
                        <img src='{$item['image']}' alt='{$item['title']}'>
                        <div>
                            <h3>{$item['title']}</h3>
                            <p>{$item['summary']}</p>
                            <a href='{$item['link']}' class='button'>Read More</a>
                        </div>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 College Events & News Hub. All Rights Reserved.</p>
        <nav>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Privacy Policy</a>
        </nav>
    </footer>

</body>
</html>
