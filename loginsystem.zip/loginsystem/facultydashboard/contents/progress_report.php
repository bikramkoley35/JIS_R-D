<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progress Report Submission</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 600px;
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            text-align: center;
            animation: fadeIn 0.8s ease-in-out;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-size: 1rem;
            font-weight: bold;
            color: #444;
            text-align: left;
        }

        input, textarea {
            padding: 12px;
            font-size: 1rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #f9f9f9;
            outline: none;
            transition: all 0.3s ease-in-out;
        }

        input:focus, textarea:focus {
            border-color: #6a11cb;
            box-shadow: 0 0 8px rgba(106, 17, 203, 0.3);
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        button {
            padding: 12px;
            background: #6a11cb;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            margin-top: 10px;
        }

        button:hover {
            background-color: #4b0ca1;
            transform: translateY(-2px);
        }

        button:active {
            transform: translateY(0);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Progress Report Submission</h2>
        <form id="progress-form" method="POST" action="contents/submit_progress.php" enctype="multipart/form-data">
            <label for="proposal-id">Proposal ID:</label>
            <input type="text" id="proposal-id" name="proposal-id" required>

            <label for="report-date">Report Date:</label>
            <input type="date" id="report-date" name="report-date" required>

            <label for="project-progress">Progress (%):</label>
            <input type="number" id="project-progress" name="project-progress" min="0" max="100" required>

            <label for="challenges">Challenges (optional):</label>
            <textarea id="challenges" name="challenges"></textarea>

            <label for="progress-file">Upload Progress Report:</label>
            <input type="file" id="progress-file" name="progress-file" required>

            <button type="submit">Submit Progress</button>
        </form>
    </div>
</body>
</html>
