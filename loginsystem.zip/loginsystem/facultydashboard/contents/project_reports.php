<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quarterly Evaluation and Reporting</title>
    <style>
        /* Global Styles */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
        }

        body {
            
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            width: 100%;
            animation: fadeIn 0.8s ease-in-out;
        }

        h1, h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-size: 1.1em;
            font-weight: bold;
            color: #444;
        }

        input, textarea {
            padding: 12px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 100%;
            background: #f9f9f9;
            outline: none;
            transition: all 0.3s ease-in-out;
        }

        input:focus, textarea:focus {
            border-color: #6a11cb;
            box-shadow: 0 0 8px rgba(106, 17, 203, 0.3);
        }

        button {
            background: #6a11cb;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
        }

        button:hover {
            background-color: #4b0ca1;
            transform: translateY(-2px);
        }

        button:active {
            transform: translateY(0);
        }

        /* Fade-in animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Quarterly Evaluation and Reporting</h1>

        <!-- Project Proposal Submission Form -->
        <section id="project-proposal">
            <h2>Project Proposal Submission</h2>
            <form id="proposal-form" method="POST" action="contents/submit_proposal.php" enctype="multipart/form-data">
                <label for="project-name">Project Name:</label>
                <input type="text" id="project-name" name="project-name" required>

                <label for="project-description">Project Description:</label>
                <textarea id="project-description" name="project-description" required></textarea>

                <label for="proposal-file">Upload Proposal Document:</label>
                <input type="file" id="proposal-file" name="proposal-file" required>

                <button type="submit">Submit Proposal</button>
            </form>
        </section>
    </div>

    <script>
        document.getElementById("proposal-form").addEventListener("submit", function(event) {
            const projectName = document.getElementById("project-name").value;
            const projectDescription = document.getElementById("project-description").value;

            if (!projectName || !projectDescription) {
                alert("Please fill out all fields before submitting.");
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
