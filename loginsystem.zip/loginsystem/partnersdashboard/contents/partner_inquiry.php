
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partnership Inquiry Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 100%;
            max-width: 450px;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 12px;
            color: #555;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
            min-height: 120px;
        }

        button {
            width: 100%;
            background: #007BFF;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 18px;
            transition: background 0.3s;
        }

        button:hover {
            background: #0056b3;
        }
    </style>
</head>


<body>
    <div class="container">
        <h2>Partnership Inquiry Form</h2>
        <form action="" method="POST">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" required>

            <label for="institution">Institution/Company:</label>
            <input type="text" id="institution" name="institution" required>

            <label for="country">Country:</label>
            <input type="text" id="country" name="country" required>

            <label for="address">Full Address:</label>
            <input type="text" id="address" name="address" required>

            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>

            <button type="submit">Submit Inquiry</button>
        </form>
    </div>
</body>
</html>
<?php
//session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer
require '../vendor/autoload.php'; // Ensure PHPMailer is installed via Composer

$conn = new mysqli("localhost", "root", "", "test");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the partner is logged in
if (!isset($_SESSION["partner_id"])) {
    //header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $partner_id = $_SESSION["partner_id"]; // Fetch logged-in partner ID
    $name = $_POST['name'];
    $email = $_POST['email'];
    $institution = $_POST['institution'];
    $country = $_POST['country'];
    $address = $_POST['address'];
    $message = $_POST['message'];

    // Insert inquiry into the database
    $sql = "INSERT INTO partnership_inquiries (partner_id, name, email, institution, country, address, message, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'In Progress')";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $partner_id, $name, $email, $institution, $country, $address, $message);

    if ($stmt->execute()) {
        echo "<script>alert('Your inquiry has been submitted successfully!');</script>";

        // Send email using PHPMailer
        $mail = new PHPMailer(true);
        try {
            // SMTP Configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'supriyojanaa@gmail.com';
            $mail->Password = 'udkzgwyqbxuduwut';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('supriyojanaa@gmail.com', 'Inquiry Received - JIS GEPO');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = "Inquiry Received - JIS GEPO";
            $mail->Body    = "
                <html>
                <head>
                    <title>Inquiry Confirmation</title>
                </head>
                <body>
                    <p>Dear $name,</p>
                    <p>Thank you for reaching out to JIS GEPO. We have received your partnership inquiry and will review it as soon as possible.</p>
                    <p>Here are your submitted details:</p>
                    <ul>
                        <li><strong>Name:</strong> $name</li>
                        <li><strong>Email:</strong> $email</li>
                        <li><strong>Institution:</strong> $institution</li>
                        <li><strong>Country:</strong> $country</li>
                        <li><strong>Address:</strong> $address</li>
                        <li><strong>Message:</strong> $message</li>
                    </ul>
                    <p>We will get back to you shortly.</p>
                    <p>Best regards,</p>
                    <p><strong>JIS GEPO Team</strong></p>
                </body>
                </html>
            ";

            // Send the email
            $mail->send();
            echo "<script>alert('Confirmation email sent to the sender successfully!');</script>";
        } catch (Exception $e) {
            echo "<script>alert('Email could not be sent. Error: {$mail->ErrorInfo}');</script>";
        }

        echo "<script>window.location.href='partner_inquiry.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error submitting inquiry. Please try again.');</script>";
    }
}
?>
