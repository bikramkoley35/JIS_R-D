<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $status = $_POST['status'];

    // Validate status
    $valid_statuses = ['In Progress', 'Accepted', 'Rejected'];
    if (!in_array($status, $valid_statuses)) {
        die("Invalid status!");
    }

    // Database connection
    $conn = new mysqli("localhost", "root", "", "test");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Update status
    $sql = "UPDATE partnership_inquiries SET status='$status' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Success";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>
