<?php
$servername = "localhost";
$username = "root"; // Change if needed
$password = "";
$dbname = "success_stories_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $description = $_POST["description"];
    $image_url = $_POST["image_url"];
    $company_name = $_POST["company_name"];
    $offered_lpa = $_POST["offered_lpa"];

    $sql = "INSERT INTO stories (title, description, image_url, company_name, offered_lpa) VALUES ('$title', '$description', '$image_url', '$company_name', '$offered_lpa')";

    if ($conn->query($sql) === TRUE) {
        echo "New record added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel - Add Success Story</title>
</head>
<body>
    <h2>Add Success Story</h2>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title" required><br>
        
        <label>Description:</label>
        <textarea name="description" required></textarea><br>
        
        <label>Image URL:</label>
        <input type="text" name="image_url" required><br>
        
        <label>Company Name:</label>
        <input type="text" name="company_name" required><br>
        
        <label>Offered LPA:</label>
        <input type="number" step="0.01" name="offered_lpa" required><br>
        
        <button type="submit">Submit</button>
    </form>
</body>
</html>
