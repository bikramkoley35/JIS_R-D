<?php

// Rest of the file code
?>

<?php
// Database configuration
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'test';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
