<?php

// Database connection (update with your DB credentials)
require 'db_config.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Capture and sanitize the input
$college_code = isset($_POST['college_code']) ? strtolower(trim($_POST['college_code'])) : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', Arial, sans-serif;
            background-color: #f7f8fc;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .form-container {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-container h2 {
            font-size: 26px;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        .form-container p {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 20px;
        }
        .form-container .input-group {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .form-input {
            padding: 12px 15px;
            width: 260px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border 0.3s ease;
        }
        .form-input:focus {
            outline: none;
            border-color: #007bff;
        }
        .form-button {
            padding: 12px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .form-button:hover {
            background-color: #0056b3;
        }
        h2 {
            color: #2c3e50;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .search-container {
            text-align: center;
            margin: 20px 0;
        }
        .search-container input {
            width: 260px;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .search-container input:focus {
            outline: none;
            border-color: #007bff;
        }
        #noIdMessage {
            color: red;
            font-size: 16px;
            text-align: center;
            margin-top: 20px;
            display: none;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden;
        }
        thead th {
            background-color: #007bff;
            color: #fff;
            text-transform: uppercase;
            font-size: 14px;
            padding: 12px;
            text-align: left;
        }
        tbody td {
            padding: 12px;
            font-size: 14px;
            border-bottom: 1px solid #eaeaea;
        }
        tbody tr:last-child td {
            border-bottom: none;
        }
        tbody tr:hover {
            background-color: #f5faff;
        }
        .action-icons {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        .action-icons button {
            background: none;
            border: none;
            cursor: pointer;
        }
        .action-icons img {
            width: 20px;
            height: 20px;
        }
        .no-data {
            text-align: center;
            color: #888;
            font-size: 16px;
            margin-top: 20px;
        }
        .action-input {
            border: 1px solid #ccc;
            padding: 6px 10px;
            font-size: 14px;
            border-radius: 5px;
            width: 100%;
        }
        .action-input:focus {
            outline: none;
            border-color: #007bff;
        }
    </style>
    <script>
        function filterById() {
            const searchInput = document.getElementById('searchInput').value.trim().toLowerCase();
            const table = document.getElementById('facultyTable');
            const rows = table.getElementsByTagName('tr');
            const noIdMessage = document.getElementById('noIdMessage');

            let found = false;

            for (let i = 1; i < rows.length; i++) {
                const idCell = rows[i].getElementsByTagName('td')[0];
                const id = idCell ? idCell.textContent.trim().toLowerCase() : '';

                if (id === searchInput) {
                    rows[i].style.display = '';
                    found = true;
                } else {
                    rows[i].style.display = 'none';
                }
            }

            noIdMessage.style.display = found ? 'none' : 'block';
        }
    </script>
</head>
<body>
    <div class="container">
        <?php if (!$college_code): ?>
            <div class="form-container">
                <h2>Enter College Code</h2>
                <p>To view faculty data, please enter the college code below.</p>
                <form method="POST" action="">
                    <div class="input-group">
                        <input 
                            type="text" 
                            name="college_code" 
                            placeholder="Enter College Code" 
                            required 
                            class="form-input"
                        >
                        <button type="submit" class="form-button">Submit</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <h2>Faculty Data for College Code: <?php echo htmlspecialchars($college_code); ?></h2>
            <div class="search-container">
                <input 
                    type="text" 
                    id="searchInput" 
                    placeholder="Search by unique ID..." 
                    onkeyup="filterById()"
                >
            </div>
            <div id="noIdMessage">ID not found.</div>
            <?php
            $table_name = $conn->real_escape_string($college_code . '_faculty');
            $result = $conn->query("SELECT * FROM $table_name");

            if ($result && $result->num_rows > 0): ?>
                <table id="facultyTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>Full Name</th>
                            <th>Dept</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td>
                                    <input 
                                        type="text" 
                                        value="<?php echo htmlspecialchars($row['email']); ?>" 
                                        class="action-input"
                                    >
                                </td>
                                <td>
                                    <input 
                                        type="text" 
                                        value="<?php echo htmlspecialchars($row['full_name']); ?>" 
                                        class="action-input"
                                    >
                                </td>
                                <td>
                                    <input 
                                        type="text" 
                                        value="<?php echo htmlspecialchars($row['dept']); ?>" 
                                        class="action-input"
                                    >
                                </td>
                                <td><?php echo $row['created_at']; ?></td>
                                <td class="action-icons">
                                    <form method="POST" action="process.php" style="display:inline;">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="hidden" name="table_name" value="<?php echo $table_name; ?>">
                                        <button type="submit" name="update_entry">
                                            <img src="assets/edit-icon.svg" alt="Edit">
                                        </button>
                                    </form>
                                    <form method="POST" action="process.php" style="display:inline;">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="hidden" name="table_name" value="<?php echo $table_name; ?>">
                                        <button type="submit" name="delete_entry">
                                            <img src="assets/delete-icon.svg" alt="Delete">
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">No records found for the given College Code.</div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>
