<?php
$servername = "localhost";
$username = "root"; // Change if needed
$password = "";
$dbname = "success_stories_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch stories from database
$sql = "SELECT * FROM stories";
$result = $conn->query($sql);

// Generate HTML dynamically
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '
            <div class="swiper-slide bg-white shadow-lg rounded-lg p-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
                <img src="' . $row["image_url"] . '" class="w-full h-40 object-cover rounded-md" alt="Story">
                <h3 class="text-lg font-semibold mt-3">' . $row["title"] . '</h3>
                <p class="text-sm text-gray-600">' . $row["description"] . '</p>
                <p class="text-sm font-medium text-gray-800">🏢 Company: ' . $row["company_name"] . '</p>
                <p class="text-sm font-medium text-green-600">💰 Offered Package: ' . $row["offered_lpa"] . ' LPA</p>
            </div>';
    }
} else {
    echo "<p>No stories available.</p>";
}

$conn->close();
?>
