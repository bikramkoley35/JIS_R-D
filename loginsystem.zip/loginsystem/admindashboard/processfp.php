<?php


require 'db_config.php';

// 3. Edit Principal

    
    if (isset($_POST['edit_principle'])) {
        $college_code = trim($_POST['college_code']);
        $principal_name = trim($_POST['principal_name']);
    
        if (empty($college_code) || empty($principal_name)) {
            echo "<script>alert('College code or Principal name cannot be empty.');
            window.history.back();</script>";
            exit;
        }
    
        $sql = "UPDATE principles SET principle_name = ? WHERE college_code = ?";
        $stmt = $conn->prepare($sql);
    
        if ($stmt === false) {
            echo "<script>alert('Failed to prepare the SQL statement.');
            window.location.href = 'index.php';</script>";
            exit;
        }
    
        $stmt->bind_param('ss', $principal_name, $college_code);
    
        if ($stmt->execute()) {
            echo "<script>alert('Principal Table updated successfully.');
            window.location.href = 'index.php';</script>";
        } else {
            echo "<script>alert('Failed to update Principal Table.');
            window.location.href = 'index.php';</script>";
        }
    
        $stmt->close();
    }
    
    

    // 4. Delete Principal
    elseif (isset($_POST['delete_principle'])) {
        $college_code = intval($_POST['college_code']);

        $sql = "DELETE FROM partner_colleges WHERE college_code = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);

        if ($stmt->execute()) {
            echo "<script>alert('College deleted successfully');
            window.location.href = 'index.php'
             </script>";
           
        } else {
            echo "<script>alert('Failed to delete college');
            window.location.href = 'index.php'
             </script>";
            
        }
    }
?> 